const { app, BrowserWindow, ipcMain, dialog } = require('electron')
const path = require('path')
const fs = require('fs')
const { spawn, exec } = require('child_process')

let ollamaProcess = null
let DATA_DIR, SETTINGS_FILE, CHAT_HISTORY_FILE

function initPaths() {
  DATA_DIR = path.join(app.getPath('userData'), 'folio-data')
  SETTINGS_FILE = path.join(DATA_DIR, 'settings.json')
  CHAT_HISTORY_FILE = path.join(DATA_DIR, 'chat-history.json')
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true })
}

function getOllamaPath() {
  const c = [
    path.join(process.env.LOCALAPPDATA||'','Programs','Ollama','ollama.exe'),
    path.join(process.env.ProgramFiles||'','Ollama','ollama.exe'),
    path.join(process.resourcesPath||'','resources','ollama.exe'),
  ]
  for(const p of c){ try{ if(fs.existsSync(p)) return p }catch{} }
  return 'ollama'
}

function startOllama(){
  try{
    ollamaProcess = spawn(getOllamaPath(),['serve'],{detached:false,stdio:'ignore',windowsHide:true})
    ollamaProcess.on('error',()=>{})
  }catch{}
}

function createWindow(){
  const win = new BrowserWindow({
    width:1400,height:900,minWidth:800,minHeight:600,backgroundColor:'#0f0a04',
    webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false,webSecurity:false}
  })
  win.loadFile(path.join(__dirname,'..','dist','index.html'))
}

app.whenReady().then(()=>{ initPaths(); startOllama(); setTimeout(createWindow,1000) })
app.on('window-all-closed',()=>{ try{ollamaProcess?.kill()}catch{}; if(process.platform!=='darwin')app.quit() })
app.on('activate',()=>{ if(BrowserWindow.getAllWindows().length===0)createWindow() })

ipcMain.handle('open-pdf',async()=>{
  const{filePaths,canceled}=await dialog.showOpenDialog({filters:[{name:'PDF',extensions:['pdf']}],properties:['openFile']})
  if(canceled||!filePaths[0])return null
  return{name:path.basename(filePaths[0]),path:filePaths[0],data:fs.readFileSync(filePaths[0]).toString('base64')}
})

// Re-read a PDF from its saved path (for session restore)
ipcMain.handle('read-pdf-by-path',(_,filePath)=>{
  try{
    if(!filePath||!fs.existsSync(filePath))return null
    return{name:path.basename(filePath),path:filePath,data:fs.readFileSync(filePath).toString('base64')}
  }catch{ return null }
})

ipcMain.handle('save-settings',(_,data)=>{
  try{ fs.writeFileSync(SETTINGS_FILE,JSON.stringify(data,null,2)); return true }catch(e){ return false }
})

ipcMain.handle('load-settings',()=>{
  try{ if(fs.existsSync(SETTINGS_FILE))return JSON.parse(fs.readFileSync(SETTINGS_FILE,'utf8')) }catch{}
  return null
})

// Chat history persistence (separate file, keeps last 200 messages)
ipcMain.handle('save-chat-history',(_,messages)=>{
  try{
    const trimmed = Array.isArray(messages) ? messages.slice(-200) : []
    fs.writeFileSync(CHAT_HISTORY_FILE,JSON.stringify(trimmed,null,2))
    return true
  }catch{ return false }
})

ipcMain.handle('load-chat-history',()=>{
  try{ if(fs.existsSync(CHAT_HISTORY_FILE))return JSON.parse(fs.readFileSync(CHAT_HISTORY_FILE,'utf8')) }catch{}
  return []
})

ipcMain.handle('install-ollama',async(event)=>{
  return new Promise(resolve=>{
    const proc=exec('winget install Ollama.Ollama --silent --accept-package-agreements --accept-source-agreements',(err)=>{
      resolve({success:!err,error:err?.message})
    })
    proc.stdout?.on('data',d=>event.sender.send('install-progress',d.toString()))
    proc.stderr?.on('data',d=>event.sender.send('install-progress',d.toString()))
  })
})
