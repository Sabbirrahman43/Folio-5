import React, { useState, useCallback, useEffect, useRef } from 'react'
import { extractBook } from './utils/pdfExtract'
import { THEMES } from './utils/themes'
import { loadSettings, saveSettings, loadChatHistory, saveChatHistory } from './utils/storage'
import Welcome from './components/Welcome'
import BookReader from './components/BookReader'
import LyraPanel from './components/LyraPanel'
import SettingsPanel from './components/SettingsPanel'

export default function App() {
  const [settings, setSettings] = useState(null)
  const [book, setBook] = useState(null)
  const [bookPath, setBookPath] = useState('')
  const [bookTitle, setBookTitle] = useState('')
  const [loading, setLoading] = useState(false)
  const [fileName, setFileName] = useState('')
  const [lyraOpen, setLyraOpen] = useState(false)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [selectedText, setSelectedText] = useState('')
  const [pepperMode, setPepperMode] = useState(false)
  const [currentPage, setCurrentPage] = useState(null)
  const [msgs, setMsgs] = useState([])
  const saveTimer = useRef(null)
  const chatSaveTimer = useRef(null)
  const restoredRef = useRef(false)

  useEffect(() => {
    loadSettings().then(s => setSettings(s))
    loadChatHistory().then(h => setMsgs(h))
  }, [])

  // Session restore: reload last book
  useEffect(() => {
    if (!settings || restoredRef.current) return
    restoredRef.current = true
    if (settings.lastBookPath && window.api?.readPDFByPath) {
      window.api.readPDFByPath(settings.lastBookPath).then(async r => {
        if (!r) return
        setFileName(r.name)
        setBookPath(r.path)
        setBookTitle(r.name.replace(/\.pdf$/i, ''))
        setLoading(true)
        try { const b = await extractBook(r.data); setBook(b) } catch {}
        setLoading(false)
      })
    }
  }, [settings])

  const changeSetting = useCallback((key, val) => {
    setSettings(prev => {
      const next = { ...prev, [key]: val }
      clearTimeout(saveTimer.current)
      saveTimer.current = setTimeout(() => saveSettings(next), 600)
      return next
    })
  }, [])

  const changeSettings = useCallback((updates) => {
    setSettings(prev => {
      const next = { ...prev, ...updates }
      clearTimeout(saveTimer.current)
      saveTimer.current = setTimeout(() => saveSettings(next), 600)
      return next
    })
  }, [])

  const updateMsgs = useCallback((updater) => {
    setMsgs(prev => {
      const next = typeof updater === 'function' ? updater(prev) : updater
      clearTimeout(chatSaveTimer.current)
      chatSaveTimer.current = setTimeout(() => saveChatHistory(next), 1000)
      return next
    })
  }, [])

  const handleHighlightsChange = useCallback((path, newHighlights) => {
    setSettings(prev => {
      const next = { ...prev, highlights: { ...prev.highlights, [path]: newHighlights } }
      saveSettings(next)
      return next
    })
  }, [])

  // Save scroll position per book
  const handleScrollPositionChange = useCallback((path, scrollTop) => {
    setSettings(prev => {
      const next = { ...prev, scrollPositions: { ...(prev.scrollPositions || {}), [path]: scrollTop } }
      saveSettings(next)
      return next
    })
  }, [])

  const openPDF = async () => {
    let base64 = null, name = '', path = ''
    if (window.api) {
      const r = await window.api.openPDF()
      if (!r) return
      base64 = r.data; name = r.name; path = r.path || r.name
    } else {
      const file = await new Promise(res => {
        const inp = document.createElement('input'); inp.type = 'file'; inp.accept = '.pdf'
        inp.onchange = e => res(e.target.files[0]); inp.click()
      })
      if (!file) return
      base64 = await new Promise(res => {
        const r = new FileReader(); r.onload = e => res(e.target.result.split(',')[1]); r.readAsDataURL(file)
      })
      name = file.name; path = file.name
    }

    setLoading(true); setFileName(name); setBookPath(path)
    setBookTitle(name.replace(/\.pdf$/i, ''))
    setCurrentPage(null)
    changeSettings({ lastBookPath: path, lastBookName: name })

    try { const b = await extractBook(base64); setBook(b) }
    catch { alert('Could not read this PDF.') }
    setLoading(false)
  }

  const handleAskAI = useCallback(text => {
    setSelectedText(text)
    setLyraOpen(true)
    setSettingsOpen(false)
  }, [])

  // Keyboard shortcuts
  useEffect(() => {
    const onKey = e => {
      if (e.target.tagName === 'TEXTAREA' || e.target.tagName === 'INPUT') return
      if (e.key === 'Escape') { setLyraOpen(false); setSettingsOpen(false); if (pepperMode) setPepperMode(false) }
      if (e.key === 'F11') { e.preventDefault(); setPepperMode(v => !v) }
      if ((e.key === 'a' || e.key === 'A') && (e.metaKey || e.ctrlKey) && !e.shiftKey) { e.preventDefault(); setLyraOpen(v => !v) }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [pepperMode])

  if (!settings) {
    return <div style={{ height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#0f0a04' }}>
      <div style={{ width: 32, height: 32, border: '2px solid #2a1808', borderTopColor: '#c4902a', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
    </div>
  }

  const T = THEMES[settings.theme] || THEMES.dark

  const readerSettings = {
    ...settings,
    onAskAI: handleAskAI,
    onHighlightsChange: handleHighlightsChange,
    onScrollPositionChange: handleScrollPositionChange,
  }

  // Focus (Pepper) mode
  if (pepperMode && book) {
    return (
      <div style={{ height: '100vh', display: 'flex', flexDirection: 'column', background: T.bg, overflow: 'hidden' }}>
        <div style={{ position: 'fixed', top: 0, left: 0, right: lyraOpen ? 380 : 0, zIndex: 10, display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '7px 20px', background: T.bg + 'f0', backdropFilter: 'blur(10px)', borderBottom: `1px solid ${T.border}` }}>
          <span style={{ color: T.textMuted, fontFamily: 'monospace', fontSize: 11 }}>{fileName}</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button onClick={() => setLyraOpen(v => !v)} style={{ ...topBtn(T), color: lyraOpen ? T.heading : T.textMuted }}>✦ {settings.personaName}</button>
            <button onClick={() => setPepperMode(false)} style={topBtn(T)}>Exit (Esc)</button>
          </div>
        </div>
        <div style={{ position: 'absolute', top: 36, bottom: 0, left: 0, right: lyraOpen ? 380 : 0, display: 'flex', flexDirection: 'column' }}>
          <BookReader book={book} settings={readerSettings} bookPath={bookPath} onPageChange={setCurrentPage} />
        </div>
        {lyraOpen && (
          <LyraPanel open settings={settings} onSettingsChange={changeSetting} onClose={() => setLyraOpen(false)}
            selectedText={selectedText} clearSelection={() => setSelectedText('')}
            msgs={msgs} setMsgs={updateMsgs} bookTitle={bookTitle} currentPage={currentPage} />
        )}
      </div>
    )
  }

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column', background: T.bg, overflow: 'hidden', transition: 'background 0.4s ease' }}>

      {/* Top bar */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '7px 16px', flexShrink: 0, background: T.bar, borderBottom: `1px solid ${T.border}`, WebkitAppRegion: 'drag' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, WebkitAppRegion: 'no-drag' }}>
          <span style={{ fontFamily: 'Georgia,serif', fontSize: 20, color: '#c4902a' }}>𝔉</span>
          {fileName && <span style={{ color: T.textMuted, fontFamily: 'monospace', fontSize: 11, maxWidth: 240, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{fileName}</span>}
        </div>
        <div style={{ display: 'flex', gap: 6, alignItems: 'center', WebkitAppRegion: 'no-drag' }}>
          <button onClick={openPDF} style={topBtn(T)}>Open PDF</button>
          {book && <button onClick={() => setPepperMode(true)} style={topBtn(T)} title="Focus mode (F11)">🌿 Focus</button>}
          <button onClick={() => { setSettingsOpen(v => !v); setLyraOpen(false) }} style={{ ...topBtn(T), background: settingsOpen ? T.surface : 'transparent', color: settingsOpen ? T.heading : T.textMuted }}>⚙ Settings</button>
          <button
            onClick={() => { setLyraOpen(v => !v); setSettingsOpen(false) }}
            style={{ ...topBtn(T), background: lyraOpen ? T.surface : 'transparent', color: lyraOpen ? T.heading : T.textMuted, display: 'flex', alignItems: 'center', gap: 5 }}
          >
            <span style={{ fontSize: 13 }}>✦</span> {settings.personaName}
          </button>
        </div>
      </div>

      {/* Main content */}
      <div style={{ flex: 1, position: 'relative', overflow: 'hidden', display: 'flex' }}>
        {settingsOpen && (
          <SettingsPanel settings={settings} onChange={changeSetting} onClose={() => setSettingsOpen(false)} />
        )}
        <div style={{ flex: 1, position: 'relative', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
          {loading && (
            <div style={{ flex: 1, height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: T.bg }}>
              <div style={{ width: 32, height: 32, border: `2px solid ${T.border}`, borderTopColor: '#c4902a', borderRadius: '50%', animation: 'spin 0.8s linear infinite', marginBottom: 16 }} />
              <p style={{ color: T.textMuted, fontFamily: "'Lora',Georgia,serif", fontSize: 18, fontStyle: 'italic' }}>Loading book...</p>
            </div>
          )}
          {!loading && !book && <Welcome onOpen={openPDF} onSettings={() => setSettingsOpen(true)} theme={settings.theme} />}
          {!loading && book && (
            <BookReader
              book={book}
              settings={readerSettings}
              bookPath={bookPath}
              onPageChange={setCurrentPage}
            />
          )}

          {book && !lyraOpen && (
            <div style={{ position: 'absolute', bottom: 10, left: '50%', transform: 'translateX(-50%)', pointerEvents: 'none' }}>
              <span style={{ color: T.border, fontFamily: 'monospace', fontSize: 10 }}>Select text → Paint or Ask {settings.personaName} &nbsp;·&nbsp; F11 for Focus &nbsp;·&nbsp; ⌘A for AI</span>
            </div>
          )}
        </div>

        {lyraOpen && !settingsOpen && (
          <LyraPanel
            open={lyraOpen}
            settings={settings}
            onSettingsChange={changeSetting}
            onClose={() => setLyraOpen(false)}
            selectedText={selectedText}
            clearSelection={() => setSelectedText('')}
            msgs={msgs}
            setMsgs={updateMsgs}
            bookTitle={bookTitle}
            currentPage={currentPage}
          />
        )}
      </div>
    </div>
  )
}

const topBtn = T => ({ padding: '5px 11px', background: 'transparent', border: `1px solid ${T.border}`, color: T.textMuted, fontFamily: 'monospace', fontSize: 11, borderRadius: 3, cursor: 'pointer' })
