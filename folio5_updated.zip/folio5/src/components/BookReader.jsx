import React, { useState, useRef, useCallback, useMemo, useEffect } from 'react'
import { textToBlocks, renderPage } from '../utils/pdfExtract'
import { THEMES, FONTS } from '../utils/themes'

const HL_COLORS = [
  { id: 'yellow', bg: 'rgba(255,210,0,0.38)',  dot: '#c8a800' },
  { id: 'green',  bg: 'rgba(60,180,80,0.30)',  dot: '#30a840' },
  { id: 'blue',   bg: 'rgba(60,140,255,0.28)', dot: '#3080ee' },
  { id: 'pink',   bg: 'rgba(240,80,130,0.28)', dot: '#e04080' },
  { id: 'orange', bg: 'rgba(255,130,30,0.32)', dot: '#e06800' },
]

// ─── Comic Page ───────────────────────────────────────────────────
// Lazy-loaded via IntersectionObserver — no blocking renders
function ComicPage({ pageNum, T, onVisible }) {
  const [dataUrl, setDataUrl] = useState(null)
  const [loading, setLoading] = useState(false)
  const ref = useRef(null)

  useEffect(() => {
    const obs = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        onVisible?.(pageNum)
        if (!dataUrl && !loading) {
          setLoading(true)
          renderPage(pageNum).then(url => {
            setDataUrl(url)
            setLoading(false)
          }).catch(() => setLoading(false))
          obs.disconnect()
        }
      }
    }, { rootMargin: '600px', threshold: 0.01 })
    if (ref.current) obs.observe(ref.current)
    return () => obs.disconnect()
  }, [pageNum])

  return (
    <div ref={ref} style={{ width: '100%', background: '#000', marginBottom: 2 }}>
      {dataUrl ? (
        <img
          src={dataUrl}
          alt={`Page ${pageNum}`}
          style={{ width: '100%', maxWidth: 900, display: 'block', margin: '0 auto' }}
          loading="lazy"
        />
      ) : (
        <div style={{
          height: 480, display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: T.textMuted, fontFamily: 'monospace', fontSize: 12,
        }}>
          {loading ? (
            <div style={{ textAlign: 'center' }}>
              <div style={{ width: 24, height: 24, border: `2px solid ${T.border}`, borderTopColor: '#c4902a', borderRadius: '50%', animation: 'spin 0.8s linear infinite', margin: '0 auto 8px' }} />
              <span>Rendering page {pageNum}...</span>
            </div>
          ) : (
            <span style={{ opacity: 0.3 }}>Page {pageNum}</span>
          )}
        </div>
      )}
    </div>
  )
}

// ─── Comic Reader ─────────────────────────────────────────────────
function ComicReader({ book, T, scrollTop, onScroll, onPageChange }) {
  const ref = useRef(null)

  // Restore scroll position once mounted
  useEffect(() => {
    if (ref.current && scrollTop > 0) {
      ref.current.scrollTop = scrollTop
    }
  }, [])

  const handleScroll = useCallback(() => {
    if (ref.current) onScroll?.(ref.current.scrollTop)
  }, [onScroll])

  return (
    <div ref={ref} onScroll={handleScroll} style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden', background: '#111' }}>
      <div style={{ maxWidth: 900, margin: '0 auto' }}>
        {book.pages.map(page => (
          <ComicPage key={page.num} pageNum={page.num} T={T} onVisible={onPageChange} />
        ))}
        <div style={{ textAlign: 'center', padding: '40px 0', color: T.textMuted, fontFamily: 'monospace', fontSize: 12 }}>
          ∽ End · {book.totalPages} pages ∽
        </div>
      </div>
    </div>
  )
}

// ─── Selection Tooltip ────────────────────────────────────────────
function SelectionTooltip({ tooltip, onPaint, onAskAI, activeColor, T }) {
  if (!tooltip) return null
  const c = HL_COLORS.find(c => c.id === activeColor)
  return (
    <div
      onMouseDown={e => e.preventDefault()}
      style={{
        position: 'fixed',
        left: tooltip.x,
        top: tooltip.y - 10,
        transform: 'translate(-50%,-100%)',
        background: T.surface,
        border: `1px solid ${T.border}`,
        borderRadius: 8, padding: '5px',
        display: 'flex', gap: 3, zIndex: 9999,
        boxShadow: '0 4px 24px rgba(0,0,0,0.5)',
        animation: 'fadeIn 0.12s ease',
        pointerEvents: 'auto',
      }}
    >
      <button
        onMouseDown={e => { e.preventDefault(); onPaint() }}
        style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '6px 10px', background: 'transparent', border: 'none', cursor: 'pointer', borderRadius: 5 }}
      >
        <div style={{ width: 10, height: 10, borderRadius: '50%', background: c?.bg, border: `1px solid ${c?.dot}` }} />
        <span style={{ color: T.text, fontFamily: 'monospace', fontSize: 11 }}>Paint</span>
      </button>
      <div style={{ width: 1, background: T.border }} />
      <button
        onMouseDown={e => { e.preventDefault(); onAskAI() }}
        style={{ padding: '6px 12px', background: 'transparent', border: 'none', color: T.heading, fontFamily: 'monospace', fontSize: 11, cursor: 'pointer', borderRadius: 5 }}
      >✦ Ask Lyra</button>
    </div>
  )
}

// Memoized paragraph block
const TextBlock = React.memo(function TextBlock({ block, highlights, onRemoveHighlight, settings, T, fontStack }) {
  const renderText = (text) => {
    const rel = highlights.filter(h => text.includes(h.text))
    if (!rel.length) return <>{text}</>
    let parts = [{ text, hlId: null, bg: null }]
    for (const hl of rel) {
      const next = []
      for (const p of parts) {
        if (p.hlId) { next.push(p); continue }
        const idx = p.text.indexOf(hl.text)
        if (idx === -1) { next.push(p); continue }
        const c = HL_COLORS.find(x => x.id === hl.color)
        if (idx > 0) next.push({ text: p.text.slice(0, idx), hlId: null })
        next.push({ text: hl.text, hlId: hl.id, bg: c?.bg })
        if (idx + hl.text.length < p.text.length) next.push({ text: p.text.slice(idx + hl.text.length), hlId: null })
      }
      parts = next
    }
    return <>{parts.map((p, i) => p.hlId
      ? <mark key={i} onClick={() => onRemoveHighlight(p.hlId)} style={{ background: p.bg, borderRadius: 2, padding: '0 1px', cursor: 'pointer' }} title="Click to remove">{p.text}</mark>
      : <React.Fragment key={i}>{p.text}</React.Fragment>
    )}</>
  }

  if (block.type === 'pagebreak') {
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '36px 0 28px', opacity: 0.3 }}>
        <div style={{ flex: 1, height: 1, background: T.border }} />
        <span style={{ color: T.textMuted, fontFamily: 'monospace', fontSize: 9, letterSpacing: 2 }}>— {block.num} —</span>
        <div style={{ flex: 1, height: 1, background: T.border }} />
      </div>
    )
  }
  if (block.type === 'heading') {
    return (
      <h2 style={{ fontFamily: fontStack, fontSize: settings.fontSize + 8, fontWeight: 600, color: T.heading, textAlign: 'center', margin: '52px 0 28px', lineHeight: 1.3, letterSpacing: 1, userSelect: 'text' }}>
        {renderText(block.text)}
      </h2>
    )
  }
  return (
    <p style={{ fontFamily: fontStack, fontSize: settings.fontSize, lineHeight: settings.lineHeight, color: T.text, textAlign: settings.align, marginBottom: settings.lineHeight * settings.fontSize * 0.55, textIndent: settings.align === 'justify' ? '2em' : 0, userSelect: 'text', wordBreak: 'break-word', hyphens: 'auto' }}>
      {renderText(block.text)}
    </p>
  )
})

// ─── Main BookReader ──────────────────────────────────────────────
export default function BookReader({ book, settings, bookPath, onPageChange }) {
  const T = THEMES[settings.theme] || THEMES.dark
  const fontStack = FONTS.find(f => f.id === settings.font)?.stack || FONTS[0].stack

  const [highlights, setHighlights] = useState(() => (settings.highlights?.[bookPath] || []))
  const [activeColor, setActiveColor] = useState('yellow')
  const [tooltip, setTooltip] = useState(null)
  const scrollRef = useRef(null)
  // Scroll save timer — debounced to avoid hammering storage
  const scrollTimer = useRef(null)

  // Build all text blocks (memoized — only changes when book changes)
  const allBlocks = useMemo(() => {
    if (book.isComic) return []
    const blocks = []
    for (const page of book.pages) {
      const pageBlocks = textToBlocks(page.text)
      if (pageBlocks.length > 0) {
        blocks.push({ type: 'pagebreak', num: page.num })
        blocks.push(...pageBlocks)
      }
    }
    return blocks
  }, [book])

  // Restore scroll position on mount
  useEffect(() => {
    if (!scrollRef.current || book.isComic) return
    const saved = settings.scrollPositions?.[bookPath] || 0
    if (saved > 0) {
      // Small delay to ensure content is rendered
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          if (scrollRef.current) scrollRef.current.scrollTop = saved
        })
      })
    }
  }, [bookPath])

  // Track current visible page from scroll position (text reader)
  useEffect(() => {
    if (book.isComic || !scrollRef.current) return
    const el = scrollRef.current
    const updatePage = () => {
      // Estimate page from scroll ratio
      const ratio = el.scrollTop / (el.scrollHeight - el.clientHeight || 1)
      const pageNum = Math.max(1, Math.round(ratio * book.totalPages))
      onPageChange?.(pageNum)
    }
    el.addEventListener('scroll', updatePage, { passive: true })
    return () => el.removeEventListener('scroll', updatePage)
  }, [book, onPageChange])

  const handleScroll = useCallback(() => {
    if (!scrollRef.current) return
    const top = scrollRef.current.scrollTop
    clearTimeout(scrollTimer.current)
    scrollTimer.current = setTimeout(() => {
      settings.onScrollPositionChange?.(bookPath, top)
    }, 500)
  }, [bookPath, settings])

  const removeHighlight = useCallback((id) => {
    setHighlights(prev => {
      const n = prev.filter(h => h.id !== id)
      settings.onHighlightsChange?.(bookPath, n)
      return n
    })
  }, [bookPath, settings])

  const handleMouseUp = useCallback(() => {
    requestAnimationFrame(() => {
      const sel = window.getSelection()
      const text = sel?.toString().trim()
      if (!text || text.length < 3) return
      const range = sel.getRangeAt(0)
      const rect = range.getBoundingClientRect()
      if (rect.width === 0 && rect.height === 0) return
      setTooltip({ x: rect.left + rect.width / 2, y: rect.top, text })
    })
  }, [])

  const applyHighlight = useCallback(() => {
    if (!tooltip) return
    setHighlights(prev => {
      const newHL = [...prev, { id: Date.now(), text: tooltip.text, color: activeColor }]
      settings.onHighlightsChange?.(bookPath, newHL)
      return newHL
    })
    setTooltip(null)
    window.getSelection()?.removeAllRanges()
  }, [tooltip, activeColor, bookPath, settings])

  const askAI = useCallback(() => {
    if (!tooltip) return
    settings.onAskAI?.(tooltip.text)
    setTooltip(null)
    window.getSelection()?.removeAllRanges()
  }, [tooltip, settings])

  useEffect(() => {
    if (!tooltip) return
    const handler = (e) => {
      if (!e.target.closest('[data-tooltip]')) setTooltip(null)
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [tooltip])

  const maxW = settings.maxWidth === 'full' ? '100%' : settings.maxWidth

  // Comic/manga mode
  if (book.isComic) {
    const savedScroll = settings.scrollPositions?.[bookPath] || 0
    return (
      <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: '#111', overflow: 'hidden' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '5px 16px', borderBottom: `1px solid ${T.border}`, flexShrink: 0, background: T.bar }}>
          <span style={{ color: T.textMuted, fontFamily: 'monospace', fontSize: 10 }}>📖 Comic mode · {book.totalPages} pages</span>
        </div>
        <ComicReader
          book={book} T={T}
          scrollTop={savedScroll}
          onScroll={top => {
            clearTimeout(scrollTimer.current)
            scrollTimer.current = setTimeout(() => settings.onScrollPositionChange?.(bookPath, top), 500)
          }}
          onPageChange={onPageChange}
        />
      </div>
    )
  }

  // Regular text reader
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: T.bg, overflow: 'hidden' }}>
      {/* Highlight toolbar */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '5px 16px', borderBottom: `1px solid ${T.border}`, flexShrink: 0, background: T.bar }}>
        <span style={{ color: T.textMuted, fontFamily: 'monospace', fontSize: 10 }}>Highlight:</span>
        {HL_COLORS.map(c => (
          <button key={c.id} onClick={() => setActiveColor(c.id)} style={{ width: 16, height: 16, borderRadius: '50%', border: `2px solid ${activeColor === c.id ? c.dot : 'transparent'}`, background: c.bg, cursor: 'pointer', padding: 0, outline: 'none', boxShadow: activeColor === c.id ? `0 0 4px ${c.dot}` : 'none' }} />
        ))}
        {highlights.length > 0 && (
          <>
            <div style={{ width: 1, height: 14, background: T.border }} />
            <span style={{ color: T.textMuted, fontFamily: 'monospace', fontSize: 10 }}>{highlights.length} highlight{highlights.length !== 1 ? 's' : ''}</span>
            <button onClick={() => { setHighlights([]); settings.onHighlightsChange?.(bookPath, []) }} style={{ background: 'none', border: 'none', color: T.textMuted, fontFamily: 'monospace', fontSize: 10, cursor: 'pointer' }}>clear</button>
          </>
        )}
      </div>

      <div
        ref={scrollRef}
        onMouseUp={handleMouseUp}
        onScroll={handleScroll}
        style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden', padding: '48px 0 80px' }}
      >
        <div style={{ maxWidth: maxW, margin: '0 auto', padding: '0 48px' }}>
          {allBlocks.map((block, i) => (
            <TextBlock
              key={i}
              block={block}
              highlights={highlights}
              onRemoveHighlight={removeHighlight}
              settings={settings}
              T={T}
              fontStack={fontStack}
            />
          ))}
          <div style={{ textAlign: 'center', padding: '60px 0 20px', color: T.textMuted, fontFamily: fontStack, fontStyle: 'italic', fontSize: settings.fontSize - 2 }}>
            ∽ End ∽
          </div>
        </div>
      </div>

      <div data-tooltip="true">
        <SelectionTooltip
          tooltip={tooltip}
          onPaint={applyHighlight}
          onAskAI={askAI}
          activeColor={activeColor}
          T={T}
        />
      </div>
    </div>
  )
}
