import React from 'react'
import { THEMES } from '../utils/themes'

export default function Welcome({ onOpen, onSettings, theme }) {
  const T = THEMES[theme] || THEMES.dark
  return (
    <div style={{ flex:1,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',background:T.bg,userSelect:'none',height:'100%' }}>
      <div style={{ width:90,height:90,borderRadius:10,marginBottom:32,background:T.surface,border:`1px solid ${T.border}`,boxShadow:'0 0 40px rgba(180,100,20,0.1)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:48,color:'#c4902a',fontFamily:'Georgia,serif' }}>𝔉</div>
      <h1 style={{ fontFamily:"'Lora',Georgia,serif",fontSize:52,color:T.heading,margin:0,letterSpacing:3,fontWeight:400 }}>Folio</h1>
      <p style={{ color:T.textMuted,fontFamily:"'Lora',Georgia,serif",fontStyle:'italic',fontSize:18,marginTop:10,marginBottom:48 }}>Read in peace. Think with depth.</p>
      <div style={{ display:'flex',flexDirection:'column',gap:12,width:260 }}>
        <button onClick={onOpen} style={{ padding:'16px',fontFamily:"'Lora',Georgia,serif",fontSize:17,background:'linear-gradient(135deg,#c4902a,#8a6020)',color:'#1a0e05',border:'none',borderRadius:6,cursor:'pointer',boxShadow:'0 4px 20px rgba(196,144,42,0.2)' }}>Open a PDF</button>
        <button onClick={onSettings} style={{ padding:'16px',fontFamily:"'Lora',Georgia,serif",fontSize:17,background:'transparent',color:T.textMuted,border:`1px solid ${T.border}`,borderRadius:6,cursor:'pointer' }}>Settings & AI Setup</button>
      </div>
      <div style={{ position:'absolute',bottom:28,display:'flex',gap:28 }}>
        {['Book-style reading','Highlight & annotate','Lyra AI companion','Eye-safe themes'].map(t=>(
          <span key={t} style={{color:T.border,fontFamily:'monospace',fontSize:11}}>✦ {t}</span>
        ))}
      </div>
    </div>
  )
}
