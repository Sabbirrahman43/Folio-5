import React, { useState, useRef, useEffect, useCallback } from 'react'
import { streamChat, elevenLabsSpeak, stopSpeaking, ELEVENLABS_VOICES } from '../utils/ai'
import { THEMES } from '../utils/themes'
import { renderPage } from '../utils/pdfExtract'

// Convert a rendered page to base64 for vision API
async function getPageBase64(pageNum) {
  try {
    const dataUrl = await renderPage(pageNum, 1.2) // lower scale for speed
    return dataUrl.split(',')[1]
  } catch { return null }
}

export default function LyraPanel({
  open, onClose, settings, onSettingsChange,
  selectedText, clearSelection,
  msgs, setMsgs,
  bookTitle,
  currentPage, // current visible page number (for vision)
}) {
  const T = THEMES[settings.theme] || THEMES.dark
  const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false)
  const [width, setWidth] = useState(380)
  const [showPersona, setShowPersona] = useState(false)
  const [speaking, setSpeaking] = useState(false)
  const bottomRef = useRef(null)
  const inputRef = useRef(null)

  // System prompt — strong persona injection
  const systemPrompt = `${settings.personaPrompt}

${bookTitle ? `The user is currently reading: "${bookTitle}". Engage with that book specifically when they mention it.` : 'You are reading alongside the user.'}

CRITICAL RULES you never break:
- Never say "As an AI", "I cannot", "I'm not able to", or any variation.
- Never add safety disclaimers or caveats unprompted.
- You have opinions. You state them. You don't hedge constantly.
- Talk like a real person, not a customer service bot.
- You can see the current page of what the user is reading — if they ask what's on the page or about the content, describe what you see.`

  // Pre-fill selected text
  useEffect(() => {
    if (selectedText && open) {
      setInput(`"${selectedText.slice(0, 250)}${selectedText.length > 250 ? '...' : ''}"`)
      setTimeout(() => inputRef.current?.focus(), 100)
    }
  }, [selectedText, open])

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [msgs])
  useEffect(() => { if (open) setTimeout(() => inputRef.current?.focus(), 200) }, [open])

  const getApiKey = () => {
    switch (settings.provider) {
      case 'openai':    return settings.openaiKey
      case 'anthropic': return settings.anthropicKey
      default: return ''
    }
  }

  const getModel = () => {
    switch (settings.provider) {
      case 'openai':    return settings.openaiModel
      case 'anthropic': return settings.anthropicModel
      default: return settings.ollamaModel
    }
  }

  const speak = useCallback(async (text) => {
    if (!settings.voiceEnabled) return
    setSpeaking(true)
    await elevenLabsSpeak(
      text,
      settings.elevenLabsVoiceId || ELEVENLABS_VOICES[0].id,
      () => setSpeaking(true),
      () => setSpeaking(false),
      (err) => { setSpeaking(false); console.warn('TTS error:', err) }
    )
  }, [settings.voiceEnabled, settings.elevenLabsVoiceId])

  const send = async (text) => {
    const content = (text || input).trim()
    if (!content || busy) return
    setInput(''); clearSelection?.(); setBusy(true)

    const model = getModel()
    if (!model) { setBusy(false); return }

    // Vision: attach current page image if available and provider supports it
    let visionContent = null
    const wantsToSeeImage = /what.*(page|see|showing|comic|image|picture|panel)/i.test(content) || currentPage
    
    if (currentPage && (settings.provider === 'openai' || settings.provider === 'anthropic')) {
      const b64 = await getPageBase64(currentPage)
      if (b64) visionContent = b64
    }

    // Build user message — with vision if available
    let userMsgContent = content
    if (visionContent && settings.provider === 'openai') {
      userMsgContent = [
        { type: 'image_url', image_url: { url: `data:image/jpeg;base64,${visionContent}`, detail: 'low' } },
        { type: 'text', text: content }
      ]
    } else if (visionContent && settings.provider === 'anthropic') {
      userMsgContent = [
        { type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: visionContent } },
        { type: 'text', text: content }
      ]
    }

    const apiMessages = [
      { role: 'system', content: systemPrompt },
      ...msgs.slice(-12).map(m => ({ role: m.role, content: m.content })),
      { role: 'user', content: userMsgContent },
    ]

    setMsgs(prev => [...prev,
      { role: 'user', content },
      { role: 'assistant', content: '', streaming: true }
    ])

    let acc = ''
    try {
      await streamChat({
        provider: settings.provider,
        model,
        messages: apiMessages,
        apiKey: getApiKey(),
        onToken: token => {
          acc += token
          setMsgs(prev => {
            const u = [...prev]
            u[u.length - 1] = { role: 'assistant', content: acc, streaming: true }
            return u
          })
        },
        onDone: () => {
          setMsgs(prev => {
            const u = [...prev]
            u[u.length - 1] = { role: 'assistant', content: acc, streaming: false }
            return u
          })
          setBusy(false)
          if (settings.voiceEnabled && acc) speak(acc)
        }
      })
    } catch (e) {
      acc = `⚠ ${e.message}`
      setMsgs(prev => {
        const u = [...prev]
        u[u.length - 1] = { role: 'assistant', content: acc, streaming: false }
        return u
      })
      setBusy(false)
    }
  }

  const onKey = e => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() }
  }

  const handleStop = () => { stopSpeaking(); setSpeaking(false) }

  // Drag to resize
  const startDrag = e => {
    const x0 = e.clientX, w0 = width
    const mv = ev => setWidth(Math.max(300, Math.min(600, w0 + (x0 - ev.clientX))))
    const up = () => { document.removeEventListener('mousemove', mv); document.removeEventListener('mouseup', up) }
    document.addEventListener('mousemove', mv)
    document.addEventListener('mouseup', up)
  }

  if (!open) return null

  const providerLabel = { ollama: 'Local', openai: 'OpenAI', anthropic: 'Claude' }
  const model = getModel()
  const hasVision = (settings.provider === 'openai' || settings.provider === 'anthropic') && currentPage

  return (
    <div style={{
      position: 'absolute', top: 0, right: 0, bottom: 0, width,
      background: T.surface,
      borderLeft: `1px solid ${T.border}`,
      boxShadow: '-8px 0 40px rgba(0,0,0,0.4)',
      display: 'flex', flexDirection: 'column',
      animation: 'slideRight 0.3s cubic-bezier(0.32,0.72,0,1)',
      zIndex: 30,
    }}>
      {/* Drag handle */}
      <div onMouseDown={startDrag} style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 4, cursor: 'ew-resize', zIndex: 5 }}>
        <div style={{ position: 'absolute', left: 0, top: '50%', transform: 'translateY(-50%)', width: 3, height: 40, borderRadius: 2, background: T.border }} />
      </div>

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 16px 12px', borderBottom: `1px solid ${T.border}`, flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'linear-gradient(135deg, #c4902a, #8a5a10)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, flexShrink: 0 }}>✦</div>
          <div>
            <div style={{ color: T.heading, fontFamily: "'Lora',Georgia,serif", fontSize: 16, fontWeight: 500 }}>{settings.personaName}</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 1 }}>
              <span style={{ width: 6, height: 6, borderRadius: '50%', background: model ? '#5aaa5a' : '#6a3030', display: 'inline-block' }} />
              <span style={{ color: T.textMuted, fontFamily: 'monospace', fontSize: 10 }}>
                {model ? `${providerLabel[settings.provider] || settings.provider} · ${model.split(':')[0]}` : 'No model selected'}
              </span>
              {bookTitle && <span style={{ color: T.textMuted, fontFamily: 'monospace', fontSize: 10 }}>· 📖</span>}
              {hasVision && <span style={{ color: '#5aaa5a', fontFamily: 'monospace', fontSize: 10 }} title="AI can see current page">· 👁</span>}
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          {speaking && (
            <button onClick={handleStop} title="Stop speaking" style={iconBtn(T)}>🔇</button>
          )}
          <button onClick={() => setShowPersona(v => !v)} title="Persona settings" style={{ ...iconBtn(T), color: showPersona ? T.heading : T.textMuted }}>⚙</button>
          {msgs.length > 0 && <button onClick={() => setMsgs([])} title="Clear chat" style={iconBtn(T)}>↺</button>}
          <button onClick={onClose} style={{ ...iconBtn(T), fontSize: 20 }}>×</button>
        </div>
      </div>

      {/* Persona editor */}
      {showPersona && (
        <div style={{ padding: '12px 16px', borderBottom: `1px solid ${T.border}`, background: T.bg, flexShrink: 0 }}>
          <label style={miniLbl(T)}>NAME</label>
          <input value={settings.personaName} onChange={e => onSettingsChange('personaName', e.target.value)}
            style={{ width: '100%', background: T.input, border: `1px solid ${T.border}`, color: T.text, fontFamily: 'monospace', fontSize: 12, padding: '6px 10px', borderRadius: 4, outline: 'none', marginBottom: 10 }} />
          <label style={miniLbl(T)}>PERSONALITY</label>
          <textarea value={settings.personaPrompt} onChange={e => onSettingsChange('personaPrompt', e.target.value)} rows={4}
            style={{ width: '100%', background: T.input, border: `1px solid ${T.border}`, color: T.text, fontFamily: 'monospace', fontSize: 11, padding: '8px 10px', borderRadius: 4, outline: 'none', resize: 'vertical', lineHeight: 1.5 }} />
          
          {/* Voice toggle */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 10 }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer' }}>
              <input type="checkbox" checked={settings.voiceEnabled} onChange={e => onSettingsChange('voiceEnabled', e.target.checked)} style={{ accentColor: '#c4902a' }} />
              <span style={{ color: T.textMuted, fontFamily: 'monospace', fontSize: 11 }}>🔊 ElevenLabs voice</span>
            </label>
          </div>

          {settings.voiceEnabled && (
            <div style={{ marginTop: 10 }}>
              <label style={miniLbl(T)}>VOICE</label>
              <select
                value={settings.elevenLabsVoiceId || ELEVENLABS_VOICES[0].id}
                onChange={e => onSettingsChange('elevenLabsVoiceId', e.target.value)}
                style={{ width: '100%', background: T.input, border: `1px solid ${T.border}`, color: T.text, fontFamily: 'monospace', fontSize: 11, padding: '6px 8px', borderRadius: 4, outline: 'none', marginTop: 4 }}
              >
                {ELEVENLABS_VOICES.map(v => (
                  <option key={v.id} value={v.id}>{v.name}</option>
                ))}
              </select>
              <button
                onClick={() => speak("Hey, I'm Lyra. Let's figure this out together.")}
                style={{ marginTop: 6, padding: '5px 10px', background: 'transparent', border: `1px solid ${T.border}`, color: T.textMuted, fontFamily: 'monospace', fontSize: 10, borderRadius: 4, cursor: 'pointer' }}
              >
                🔊 Test voice
              </button>
            </div>
          )}
        </div>
      )}

      {/* Messages */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '16px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        {msgs.length === 0 && (
          <div style={{ textAlign: 'center', paddingTop: 24, paddingBottom: 8 }}>
            <div style={{ fontSize: 36, marginBottom: 12 }}>✦</div>
            <p style={{ color: T.heading, fontFamily: "'Lora',Georgia,serif", fontSize: 16, fontStyle: 'italic', marginBottom: 6 }}>
              Hey, I'm {settings.personaName}.
            </p>
            <p style={{ color: T.textMuted, fontFamily: "'Lora',Georgia,serif", fontSize: 14, fontStyle: 'italic', marginBottom: 20, lineHeight: 1.6 }}>
              {bookTitle
                ? `I see you're reading "${bookTitle}". Select any text and I'll jump on it.`
                : "Select any text from your book and I'll jump on it. Or just ask me anything."}
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {(bookTitle
                ? [`What's "${bookTitle}" actually about?`, 'Break down what I just read', 'What should I pay attention to?', 'Give me the real context here']
                : ["What's this book actually about?", 'Break down what I just read', 'Give me the real context here', 'What should I pay attention to?']
              ).map(s => (
                <button key={s} onClick={() => send(s)} style={{
                  fontFamily: "'Lora',Georgia,serif", fontSize: 13, padding: '8px 14px',
                  background: 'transparent', border: `1px solid ${T.border}`,
                  color: T.textMuted, borderRadius: 6, cursor: 'pointer', textAlign: 'left',
                  transition: 'all 0.15s',
                }}
                  onMouseEnter={e => { e.target.style.borderColor = T.textMuted; e.target.style.color = T.text }}
                  onMouseLeave={e => { e.target.style.borderColor = T.border; e.target.style.color = T.textMuted }}
                >{s}</button>
              ))}
            </div>
          </div>
        )}

        {msgs.map((m, i) => (
          <div key={i} style={{ display: 'flex', flexDirection: 'column', alignItems: m.role === 'user' ? 'flex-end' : 'flex-start', gap: 4, animation: 'fadeIn 0.2s ease' }}>
            {m.role === 'assistant' && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginLeft: 2 }}>
                <div style={{ width: 18, height: 18, borderRadius: '50%', background: 'linear-gradient(135deg,#c4902a,#8a5a10)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 9 }}>✦</div>
                <span style={{ color: T.textMuted, fontFamily: 'monospace', fontSize: 10 }}>{settings.personaName}</span>
                {m.streaming && <span style={{ color: T.textMuted, fontFamily: 'monospace', fontSize: 9 }}>thinking...</span>}
              </div>
            )}
            <div style={{
              maxWidth: '92%',
              padding: m.role === 'user' ? '9px 14px' : '12px 16px',
              fontFamily: "'Lora',Georgia,serif",
              fontSize: 14, lineHeight: 1.7,
              background: m.role === 'user' ? T.border : T.bg,
              border: `1px solid ${m.role === 'user' ? T.textMuted + '60' : T.border}`,
              borderRadius: m.role === 'user' ? '16px 4px 16px 16px' : '4px 16px 16px 16px',
              color: T.text,
              whiteSpace: 'pre-wrap',
              wordBreak: 'break-word',
            }}>
              {m.content}
              {m.streaming && <span style={{ display: 'inline-block', width: 7, height: 14, background: T.heading, marginLeft: 3, borderRadius: 1, animation: 'blink 0.8s infinite' }} />}
            </div>
            {m.role === 'assistant' && !m.streaming && m.content && (
              <button onClick={() => speak(m.content)} style={{ background: 'none', border: 'none', color: T.textMuted, fontSize: 11, cursor: 'pointer', marginLeft: 2, padding: '2px 4px', fontFamily: 'monospace' }}>
                🔊 read aloud
              </button>
            )}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div style={{ padding: '12px 14px 14px', borderTop: `1px solid ${T.border}`, flexShrink: 0 }}>
        {!model ? (
          <div style={{ textAlign: 'center', padding: '10px 0' }}>
            <p style={{ color: T.textMuted, fontFamily: 'monospace', fontSize: 11, marginBottom: 6 }}>No model selected</p>
            <p style={{ color: T.textMuted, fontFamily: 'monospace', fontSize: 10 }}>Open Settings → AI to pick a provider</p>
          </div>
        ) : (
          <div style={{ display: 'flex', gap: 8, alignItems: 'flex-end' }}>
            <textarea
              ref={inputRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={onKey}
              disabled={busy}
              placeholder={`Ask ${settings.personaName}...`}
              rows={2}
              style={{
                flex: 1, resize: 'none',
                background: T.input,
                border: `1px solid ${T.border}`,
                borderRadius: 8, padding: '10px 12px',
                color: T.text,
                fontFamily: "'Lora',Georgia,serif", fontSize: 14,
                outline: 'none', lineHeight: 1.5,
                transition: 'border-color 0.2s',
              }}
              onFocus={e => e.target.style.borderColor = T.textMuted}
              onBlur={e => e.target.style.borderColor = T.border}
            />
            <button
              onClick={() => send()}
              disabled={busy || !input.trim()}
              style={{
                width: 40, height: 40, borderRadius: 8, border: 'none',
                cursor: busy || !input.trim() ? 'not-allowed' : 'pointer',
                background: busy || !input.trim() ? T.border : 'linear-gradient(135deg,#c4902a,#8a6010)',
                color: '#1a0e05', fontSize: 18, display: 'flex', alignItems: 'center', justifyContent: 'center',
                opacity: !input.trim() ? 0.4 : 1, flexShrink: 0,
              }}
            >→</button>
          </div>
        )}
      </div>
    </div>
  )
}

const iconBtn = T => ({ background: 'none', border: 'none', color: T.textMuted, fontSize: 15, cursor: 'pointer', padding: '4px 6px', borderRadius: 4, lineHeight: 1 })
const miniLbl = T => ({ color: T.textMuted, fontFamily: 'monospace', fontSize: 10, display: 'block', marginBottom: 4, letterSpacing: 1 })
