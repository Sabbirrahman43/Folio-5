import React, { useState, useEffect } from 'react'
import { THEMES, FONTS } from '../utils/themes'
import { CLOUD_MODELS, ollamaModels, OLLAMA_MODELS, pullModel, deleteModel, ollamaRunning } from '../utils/ai'
import { ELEVENLABS_VOICES } from '../utils/ai'

export default function SettingsPanel({ settings, onChange, onClose }) {
  const T = THEMES[settings.theme] || THEMES.dark
  const [tab, setTab] = useState('reading')
  const [installedModels, setInstalledModels] = useState([])
  const [ollamaOk, setOllamaOk] = useState(null)
  const [pulling, setPulling] = useState({})
  const [installing, setInstalling] = useState(false)
  const [installLog, setInstallLog] = useState('')
  const [showKeys, setShowKeys] = useState({})

  useEffect(() => {
    ollamaRunning().then(ok => { setOllamaOk(ok); if(ok) ollamaModels().then(setInstalledModels) })
    const t = setInterval(() => ollamaRunning().then(ok => { setOllamaOk(ok); if(ok) ollamaModels().then(setInstalledModels) }), 4000)
    return () => clearInterval(t)
  }, [])

  const isInstalled = id => installedModels.some(n => n === id || n.startsWith(id.split(':')[0]))

  const pull = async id => {
    setPulling(p => ({...p,[id]:{status:'Connecting...',pct:0}}))
    try {
      await pullModel(id, prog => {
        const pct = prog.total ? Math.round((prog.completed/prog.total)*100) : 0
        setPulling(p => ({...p,[id]:{status:prog.status||'Downloading...',pct}}))
      })
      setPulling(p => {const n={...p};delete n[id];return n})
      ollamaModels().then(setInstalledModels)
    } catch {
      setPulling(p => ({...p,[id]:{status:'Error',pct:0,err:true}}))
      setTimeout(() => setPulling(p => {const n={...p};delete n[id];return n}),3000)
    }
  }

  const del = async name => {
    if(!confirm(`Remove ${name}?`)) return
    await deleteModel(name)
    ollamaModels().then(ms => { setInstalledModels(ms); if(settings.ollamaModel===name) onChange('ollamaModel',null) })
  }

  const installOllama = async () => {
    if(!window.api?.installOllama) return
    setInstalling(true); setInstallLog('Starting...\n')
    window.api.onInstallProgress(d => setInstallLog(p=>p+d))
    const r = await window.api.installOllama()
    setInstallLog(p => p + (r.success ? '\n✓ Done! Restart Folio to activate.' : `\n⚠ ${r.error}`))
    setInstalling(false)
  }

  const TABS = ['reading','ai','models','persona']

  return (
    <div style={{ position:'absolute',inset:0,zIndex:50,background:T.bg,display:'flex',flexDirection:'column' }}>
      {/* Header */}
      <div style={{ display:'flex',justifyContent:'space-between',alignItems:'center',padding:'18px 24px 14px',borderBottom:`1px solid ${T.border}` }}>
        <h2 style={{ color:T.heading,fontFamily:"'Lora',Georgia,serif",fontSize:22,fontWeight:400,margin:0 }}>Settings</h2>
        <button onClick={onClose} style={{ background:'none',border:'none',color:T.textMuted,fontSize:24,cursor:'pointer' }}>×</button>
      </div>

      {/* Tabs */}
      <div style={{ display:'flex',gap:4,padding:'10px 24px 0',borderBottom:`1px solid ${T.border}` }}>
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)} style={{ padding:'7px 16px',fontFamily:'monospace',fontSize:11,background:'transparent',border:'none',borderBottom:`2px solid ${tab===t?'#c4902a':'transparent'}`,color:tab===t?T.heading:T.textMuted,cursor:'pointer',textTransform:'uppercase',letterSpacing:1 }}>
            {t}
          </button>
        ))}
      </div>

      <div style={{ flex:1,overflowY:'auto',padding:'20px 24px' }}>

        {/* ── READING ── */}
        {tab==='reading'&&(
          <div style={{display:'flex',flexDirection:'column',gap:20}}>
            <div>
              <label style={lbl(T)}>Theme</label>
              <div style={{ display:'flex',gap:10,marginTop:8 }}>
                {Object.entries(THEMES).map(([k,t]) => (
                  <button key={k} onClick={()=>onChange('theme',k)} style={{ flex:1,padding:'10px 0',borderRadius:6,border:`2px solid ${settings.theme===k?'#c4902a':T.border}`,background:t.bg,cursor:'pointer',display:'flex',flexDirection:'column',alignItems:'center',gap:4 }}>
                    <span style={{width:20,height:20,borderRadius:'50%',background:t.text,display:'block'}}/>
                    <span style={{color:t.textMuted,fontFamily:'monospace',fontSize:9}}>{t.name}</span>
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label style={lbl(T)}>Font Family</label>
              <select value={settings.font} onChange={e=>onChange('font',e.target.value)} style={select(T)}>
                {FONTS.map(f=><option key={f.id} value={f.id}>{f.name}</option>)}
              </select>
            </div>
            <div>
              <label style={lbl(T)}>Font Size — {settings.fontSize}px</label>
              <input type="range" min={14} max={32} value={settings.fontSize} onChange={e=>onChange('fontSize',+e.target.value)}
                style={{width:'100%',accentColor:'#c4902a',marginTop:8}}/>
            </div>
            <div>
              <label style={lbl(T)}>Line Spacing — {settings.lineHeight}×</label>
              <input type="range" min={1.3} max={2.5} step={0.05} value={settings.lineHeight} onChange={e=>onChange('lineHeight',+e.target.value)}
                style={{width:'100%',accentColor:'#c4902a',marginTop:8}}/>
            </div>
            <div>
              <label style={lbl(T)}>Column Width</label>
              <div style={{display:'flex',gap:8,marginTop:8}}>
                {[['Narrow',500],['Normal',700],['Wide',900],['Full','full']].map(([name,val])=>(
                  <button key={name} onClick={()=>onChange('maxWidth',val)} style={{flex:1,padding:'8px 0',fontFamily:'monospace',fontSize:11,borderRadius:4,border:`1px solid ${settings.maxWidth===val?'#c4902a':T.border}`,background:settings.maxWidth===val?T.surface:'transparent',color:settings.maxWidth===val?T.heading:T.textMuted,cursor:'pointer'}}>{name}</button>
                ))}
              </div>
            </div>
            <div>
              <label style={lbl(T)}>Text Alignment</label>
              <div style={{display:'flex',gap:8,marginTop:8}}>
                {['justify','left','center'].map(a=>(
                  <button key={a} onClick={()=>onChange('align',a)} style={{flex:1,padding:'8px 0',fontFamily:'monospace',fontSize:11,borderRadius:4,border:`1px solid ${settings.align===a?'#c4902a':T.border}`,background:settings.align===a?T.surface:'transparent',color:settings.align===a?T.heading:T.textMuted,cursor:'pointer',textTransform:'capitalize'}}>{a}</button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── AI PROVIDER ── */}
        {tab==='ai'&&(
          <div style={{display:'flex',flexDirection:'column',gap:20}}>
            <div>
              <label style={lbl(T)}>AI Provider</label>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginTop:8}}>
                {[
                  {id:'ollama',    name:'Ollama',    sub:'Local · Free · Private', icon:'🖥'},
                  {id:'openai',    name:'OpenAI',    sub:'GPT-4o · Vision · API key', icon:'◆'},
                  {id:'anthropic', name:'Anthropic', sub:'Claude · Vision · API key', icon:'◈'},
                ].map(p=>(
                  <button key={p.id} onClick={()=>onChange('provider',p.id)} style={{
                    padding:'14px',borderRadius:6,border:`2px solid ${settings.provider===p.id?'#c4902a':T.border}`,
                    background:settings.provider===p.id?T.surface:T.bg,cursor:'pointer',textAlign:'left',
                  }}>
                    <div style={{fontSize:20,marginBottom:4}}>{p.icon}</div>
                    <div style={{color:T.heading,fontFamily:"'Lora',Georgia,serif",fontSize:15}}>{p.name}</div>
                    <div style={{color:T.textMuted,fontFamily:'monospace',fontSize:10,marginTop:2}}>{p.sub}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* OpenAI */}
            {settings.provider==='openai'&&(
              <>
                <div>
                  <label style={lbl(T)}>OpenAI API Key</label>
                  <div style={{display:'flex',gap:6,marginTop:6}}>
                    <input type={showKeys.openai?'text':'password'} value={settings.openaiKey} onChange={e=>onChange('openaiKey',e.target.value)} placeholder="sk-..." style={{...inputStyle(T),flex:1}}/>
                    <button onClick={()=>setShowKeys(k=>({...k,openai:!k.openai}))} style={smallBtn(T)}>{showKeys.openai?'🙈':'👁'}</button>
                  </div>
                </div>
                <div>
                  <label style={lbl(T)}>Model</label>
                  <select value={settings.openaiModel} onChange={e=>onChange('openaiModel',e.target.value)} style={{...select(T),marginTop:6}}>
                    {CLOUD_MODELS.openai.map(m=><option key={m.id} value={m.id}>{m.name}</option>)}
                  </select>
                </div>
              </>
            )}

            {/* Anthropic */}
            {settings.provider==='anthropic'&&(
              <>
                <div>
                  <label style={lbl(T)}>Anthropic API Key</label>
                  <div style={{display:'flex',gap:6,marginTop:6}}>
                    <input type={showKeys.anthropic?'text':'password'} value={settings.anthropicKey} onChange={e=>onChange('anthropicKey',e.target.value)} placeholder="sk-ant-..." style={{...inputStyle(T),flex:1}}/>
                    <button onClick={()=>setShowKeys(k=>({...k,anthropic:!k.anthropic}))} style={smallBtn(T)}>{showKeys.anthropic?'🙈':'👁'}</button>
                  </div>
                </div>
                <div>
                  <label style={lbl(T)}>Model</label>
                  <select value={settings.anthropicModel} onChange={e=>onChange('anthropicModel',e.target.value)} style={{...select(T),marginTop:6}}>
                    {CLOUD_MODELS.anthropic.map(m=><option key={m.id} value={m.id}>{m.name}</option>)}
                  </select>
                </div>
              </>
            )}

            {settings.provider!=='ollama'&&(
              <div style={{padding:12,background:T.surface,borderRadius:6,border:`1px solid ${T.border}`}}>
                <p style={{color:T.textMuted,fontFamily:'monospace',fontSize:11,margin:0,lineHeight:1.7}}>
                  API keys are saved locally on your device only.<br/>OpenAI and Anthropic both support vision — Lyra can see your PDF pages.
                </p>
              </div>
            )}
          </div>
        )}

        {/* ── MODELS (Ollama) ── */}
        {tab==='models'&&(
          <div>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:16}}>
              <span style={{color:ollamaOk?'#5aaa5a':'#aa5030',fontFamily:'monospace',fontSize:12}}>
                {ollamaOk===null?'Checking...':ollamaOk?`✓ Ollama running · ${installedModels.length} installed`:'⚠ Ollama not running'}
              </span>
              {!ollamaOk&&!installing&&(
                <button onClick={installOllama} style={{padding:'6px 14px',background:'linear-gradient(135deg,#c4902a,#8a6010)',border:'none',color:'#1a0e05',fontFamily:'monospace',fontSize:11,borderRadius:4,cursor:'pointer'}}>Install Ollama</button>
              )}
            </div>
            {installing&&(
              <pre style={{color:T.text,fontFamily:'monospace',fontSize:10,background:T.surface,padding:12,borderRadius:4,maxHeight:80,overflow:'auto',marginBottom:16}}>{installLog}</pre>
            )}
            <div style={{display:'flex',flexDirection:'column',gap:10}}>
              {OLLAMA_MODELS.map(m=>{
                const inst=isInstalled(m.id), active=settings.ollamaModel===m.id, ps=pulling[m.id]
                return(
                  <div key={m.id} style={{padding:'14px 16px',borderRadius:6,border:`1px solid ${active?'#c4902a':T.border}`,background:active?T.surface:T.bg,display:'flex',alignItems:'center',gap:12}}>
                    <div style={{flex:1}}>
                      <div style={{display:'flex',alignItems:'center',gap:8}}>
                        <span style={{color:T.heading,fontFamily:"'Lora',Georgia,serif",fontSize:15}}>{m.name}</span>
                        <span style={{fontSize:10,fontFamily:'monospace',padding:'1px 7px',borderRadius:10,background:m.color+'18',color:m.color}}>{m.tag}</span>
                      </div>
                      <span style={{color:T.textMuted,fontFamily:'monospace',fontSize:10}}>{m.size} · {m.ram}</span>
                      {ps&&(
                        <div style={{marginTop:6}}>
                          <div style={{height:3,background:T.border,borderRadius:2,overflow:'hidden'}}>
                            <div style={{height:'100%',width:`${ps.pct}%`,background:ps.err?'#aa4020':'#c4902a',transition:'width 0.3s'}}/>
                          </div>
                          <span style={{color:T.textMuted,fontFamily:'monospace',fontSize:9}}>{ps.status}{ps.pct>0?` ${ps.pct}%`:''}</span>
                        </div>
                      )}
                    </div>
                    <div style={{display:'flex',gap:6,flexShrink:0}}>
                      {!inst&&!ps&&<button onClick={()=>pull(m.id)} disabled={!ollamaOk} style={{...smallBtn(T),color:ollamaOk?'#c4702a':T.textMuted}}>{ollamaOk?'↓ Get':'—'}</button>}
                      {inst&&!active&&<button onClick={()=>onChange('ollamaModel',m.id)} style={{...smallBtn(T),color:'#5aaa5a',borderColor:'#2a5a2a'}}>Use</button>}
                      {active&&<span style={{color:'#c4802a',fontFamily:'monospace',fontSize:11}}>✓</span>}
                      {inst&&<button onClick={()=>del(m.id)} style={{...smallBtn(T),color:'#6a3030'}}>✕</button>}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {/* ── PERSONA ── */}
        {tab==='persona'&&(
          <div style={{display:'flex',flexDirection:'column',gap:16}}>
            <div>
              <label style={lbl(T)}>Persona Name</label>
              <input value={settings.personaName} onChange={e=>onChange('personaName',e.target.value)} style={{...inputStyle(T),marginTop:6}}/>
            </div>
            <div>
              <label style={lbl(T)}>Personality</label>
              <p style={{color:T.textMuted,fontFamily:'monospace',fontSize:10,marginTop:4,marginBottom:6}}>Define how your AI companion thinks, talks, and behaves.</p>
              <textarea value={settings.personaPrompt} onChange={e=>onChange('personaPrompt',e.target.value)} rows={8}
                style={{...inputStyle(T),resize:'vertical',lineHeight:1.6,fontFamily:"'Lora',Georgia,serif",fontSize:13}}/>
            </div>

            {/* Voice */}
            <div style={{borderTop:`1px solid ${T.border}`,paddingTop:16}}>
              <label style={lbl(T)}>Voice (ElevenLabs)</label>
              <div style={{display:'flex',alignItems:'center',gap:8,marginTop:8}}>
                <label style={{ display:'flex',alignItems:'center',gap:6,cursor:'pointer' }}>
                  <input type="checkbox" checked={settings.voiceEnabled} onChange={e=>onChange('voiceEnabled',e.target.checked)} style={{accentColor:'#c4902a'}}/>
                  <span style={{color:T.textMuted,fontFamily:'monospace',fontSize:11}}>Enable voice responses</span>
                </label>
              </div>
              {settings.voiceEnabled && (
                <div style={{marginTop:12}}>
                  <label style={lbl(T)}>Voice Selection</label>
                  <select value={settings.elevenLabsVoiceId || ELEVENLABS_VOICES[0].id} onChange={e=>onChange('elevenLabsVoiceId',e.target.value)} style={{...select(T),marginTop:6}}>
                    {ELEVENLABS_VOICES.map(v=><option key={v.id} value={v.id}>{v.name}</option>)}
                  </select>
                  <p style={{color:T.textMuted,fontFamily:'monospace',fontSize:10,marginTop:8}}>
                    Powered by ElevenLabs · High-quality neural TTS
                  </p>
                </div>
              )}
            </div>

            <button onClick={()=>{
              onChange('personaName','Lyra')
              onChange('personaPrompt',"You are Lyra. You're sharp, direct, and genuinely interesting to talk to. You don't hedge or soften things — you say what you actually think. You're brilliant but never show-offy about it. You drop honest opinions, make the user think, and keep things real. No corporate AI energy, no \"As an AI...\" garbage.")
            }} style={{...smallBtn(T),padding:'8px 16px',color:T.textMuted}}>↺ Reset to Lyra</button>
          </div>
        )}
      </div>
    </div>
  )
}

const lbl = T => ({color:T.textMuted,fontFamily:'monospace',fontSize:11,letterSpacing:1,textTransform:'uppercase'})
const select = T => ({width:'100%',background:T.input,border:`1px solid ${T.border}`,color:T.text,fontFamily:'monospace',fontSize:12,padding:'8px 10px',borderRadius:4,outline:'none',cursor:'pointer',marginTop:6})
const inputStyle = T => ({width:'100%',background:T.input,border:`1px solid ${T.border}`,color:T.text,fontFamily:'monospace',fontSize:12,padding:'8px 10px',borderRadius:4,outline:'none'})
const smallBtn = T => ({padding:'6px 12px',background:'transparent',border:`1px solid ${T.border}`,color:T.textMuted,fontFamily:'monospace',fontSize:11,borderRadius:4,cursor:'pointer'})
