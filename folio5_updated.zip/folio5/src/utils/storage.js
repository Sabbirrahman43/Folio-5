// Persistent storage — saves to Electron userData folder
// Falls back to localStorage in browser/dev mode

const DEFAULT = {
  // Reading
  theme: 'dark',
  font: 'lora',
  fontSize: 20,
  lineHeight: 1.85,
  maxWidth: 700,
  align: 'justify',
  fullWidth: false,
  // AI
  provider: 'ollama',
  ollamaModel: null,
  openaiKey: '',
  anthropicKey: '',
  openaiModel: 'gpt-4o',
  anthropicModel: 'claude-opus-4-5',
  // Persona
  personaName: 'Lyra',
  personaPrompt: `You are Lyra. You're sharp, direct, and genuinely interesting to talk to. You don't hedge or soften things — you say what you actually think. You're brilliant but never show-offy about it. You drop honest opinions, make the user think, and keep things real. No corporate AI energy, no "As an AI..." garbage. You're just a person who happens to know a lot and cares about what the user is exploring.`,
  // Voice — ElevenLabs
  voiceEnabled: false,
  elevenLabsVoiceId: 'zzAIcrq5pp7webLI6ptl',
  // Highlights per book: { [bookPath]: [{id,text,color}] }
  highlights: {},
  // Scroll position per book: { [bookPath]: number }
  scrollPositions: {},
  // Session restore
  lastBookPath: '',
  lastBookName: '',
}

export async function loadSettings() {
  if (window.api?.loadSettings) {
    const saved = await window.api.loadSettings()
    return saved ? { ...DEFAULT, ...saved } : { ...DEFAULT }
  }
  try {
    const raw = localStorage.getItem('folio-settings')
    return raw ? { ...DEFAULT, ...JSON.parse(raw) } : { ...DEFAULT }
  } catch { return { ...DEFAULT } }
}

export async function saveSettings(data) {
  if (window.api?.saveSettings) {
    await window.api.saveSettings(data)
  } else {
    try { localStorage.setItem('folio-settings', JSON.stringify(data)) } catch {}
  }
}

export async function loadChatHistory() {
  if (window.api?.loadChatHistory) {
    return await window.api.loadChatHistory() || []
  }
  try {
    const raw = localStorage.getItem('folio-chat')
    return raw ? JSON.parse(raw) : []
  } catch { return [] }
}

export async function saveChatHistory(messages) {
  if (window.api?.saveChatHistory) {
    await window.api.saveChatHistory(messages)
  } else {
    try { localStorage.setItem('folio-chat', JSON.stringify(messages.slice(-200))) } catch {}
  }
}
