export const THEMES = {
  dark:   { name:'Dark Amber',   bg:'#0f0a04', surface:'#1a1008', bar:'#140c04', text:'#d4aa7a', textMuted:'#5a3a18', heading:'#e8c88a', border:'#2a1808', input:'#200e04' },
  sepia:  { name:'Sepia',        bg:'#1a1208', surface:'#241a0e', bar:'#160e06', text:'#c8a060', textMuted:'#7a5530', heading:'#e0b870', border:'#3a2410', input:'#120a02' },
  pepper: { name:'Pepper White', bg:'#f2e8d5', surface:'#ecdfc8', bar:'#e8d8c0', text:'#2a1e10', textMuted:'#8a7060', heading:'#1a1208', border:'#d0b890', input:'#e0d0b0' },
  night:  { name:'Deep Night',   bg:'#070504', surface:'#0e0a06', bar:'#060402', text:'#b08050', textMuted:'#3a2010', heading:'#c89050', border:'#180e06', input:'#040202' },
}

export const FONTS = [
  {id:'lora',    name:'Lora',         stack:"'Lora',Georgia,serif"},
  {id:'merri',   name:'Merriweather', stack:"'Merriweather',Georgia,serif"},
  {id:'garamond',name:'EB Garamond',  stack:"'EB Garamond',Georgia,serif"},
  {id:'source',  name:'Source Serif', stack:"'Source Serif 4',Georgia,serif"},
  {id:'inter',   name:'Inter',        stack:"'Inter',system-ui,sans-serif"},
  {id:'georgia', name:'Georgia',      stack:'Georgia,serif'},
]
