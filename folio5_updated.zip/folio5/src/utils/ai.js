// Unified AI client — Ollama, OpenAI, Anthropic
// ElevenLabs TTS integration

export async function streamChat({ provider, model, messages, apiKey, onToken, onDone }) {
  switch(provider) {
    case 'ollama':    return streamOllama(model, messages, onToken, onDone)
    case 'openai':    return streamOpenAI(model, messages, apiKey, onToken, onDone)
    case 'anthropic': return streamAnthropic(model, messages, apiKey, onToken, onDone)
    default: throw new Error('Unknown provider: ' + provider)
  }
}

// ── Ollama ────────────────────────────────────────────────────────
async function streamOllama(model, messages, onToken, onDone) {
  // Separate vision messages for ollama multimodal
  const r = await fetch('http://localhost:11434/api/chat', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({model, messages, stream:true})
  })
  if(!r.ok) throw new Error('Ollama not running. Start it with: ollama serve')
  const reader = r.body.getReader(), dec = new TextDecoder()
  while(true){
    const{done,value}=await reader.read(); if(done) break
    for(const line of dec.decode(value).split('\n').filter(Boolean)){
      try{const j=JSON.parse(line); if(j.message?.content) onToken(j.message.content)}catch{}
    }
  }
  onDone?.()
}

// ── OpenAI ────────────────────────────────────────────────────────
async function streamOpenAI(model, messages, apiKey, onToken, onDone) {
  const r = await fetch('https://api.openai.com/v1/chat/completions', {
    method:'POST',
    headers:{'Content-Type':'application/json','Authorization':`Bearer ${apiKey}`},
    body: JSON.stringify({model, messages, stream:true})
  })
  if(!r.ok){ const e=await r.json(); throw new Error(e.error?.message||'OpenAI error') }
  const reader = r.body.getReader(), dec = new TextDecoder()
  while(true){
    const{done,value}=await reader.read(); if(done) break
    for(const line of dec.decode(value).split('\n').filter(Boolean)){
      if(line==='data: [DONE]'){onDone?.();return}
      if(line.startsWith('data: ')){
        try{const j=JSON.parse(line.slice(6)); const t=j.choices?.[0]?.delta?.content; if(t) onToken(t)}catch{}
      }
    }
  }
  onDone?.()
}

// ── Anthropic ─────────────────────────────────────────────────────
async function streamAnthropic(model, messages, apiKey, onToken, onDone) {
  const system = messages.find(m=>m.role==='system')?.content || ''
  const msgs = messages.filter(m=>m.role!=='system')

  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method:'POST',
    headers:{
      'Content-Type':'application/json',
      'x-api-key': apiKey,
      'anthropic-version':'2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true',
    },
    body: JSON.stringify({model, messages:msgs, system, max_tokens:2048, stream:true})
  })
  if(!r.ok){ const e=await r.json(); throw new Error(e.error?.message||'Anthropic error') }
  const reader = r.body.getReader(), dec = new TextDecoder()
  while(true){
    const{done,value}=await reader.read(); if(done) break
    for(const line of dec.decode(value).split('\n').filter(Boolean)){
      if(line.startsWith('data: ')){
        try{
          const j=JSON.parse(line.slice(6))
          if(j.type==='content_block_delta'&&j.delta?.text) onToken(j.delta.text)
          if(j.type==='message_stop') onDone?.()
        }catch{}
      }
    }
  }
}

// ── ElevenLabs TTS ────────────────────────────────────────────────
export const ELEVENLABS_API_KEY = 'sk_011cda18770313035e49eadda293a219791a138a08808f66'
export const ELEVENLABS_VOICES = [
  { id: 'zzAIcrq5pp7webLI6ptl', name: 'Lyra (Default)' },
  { id: 'WMKg7TxPpPWCryaXE42r', name: 'Lyra Alt' },
]

let currentAudio = null

export async function elevenLabsSpeak(text, voiceId, onStart, onEnd, onError) {
  try {
    // Stop any playing audio
    if (currentAudio) {
      currentAudio.pause()
      currentAudio = null
    }

    const vid = voiceId || ELEVENLABS_VOICES[0].id
    const r = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${vid}/stream`, {
      method: 'POST',
      headers: {
        'xi-api-key': ELEVENLABS_API_KEY,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        text: text.slice(0, 1000),
        model_id: 'eleven_turbo_v2_5',
        voice_settings: { stability: 0.45, similarity_boost: 0.82, style: 0.35, use_speaker_boost: true }
      })
    })

    if (!r.ok) {
      const err = await r.json().catch(() => ({}))
      throw new Error(err.detail?.message || 'ElevenLabs error')
    }

    const blob = await r.blob()
    const url = URL.createObjectURL(blob)
    const audio = new Audio(url)
    currentAudio = audio
    audio.onplay = onStart
    audio.onended = () => { URL.revokeObjectURL(url); currentAudio = null; onEnd?.() }
    audio.onerror = () => { URL.revokeObjectURL(url); currentAudio = null; onError?.('Audio playback failed') }
    await audio.play()
  } catch(e) {
    onError?.(e.message)
  }
}

export function stopSpeaking() {
  if (currentAudio) { currentAudio.pause(); currentAudio = null }
}

// ── Ollama helpers ────────────────────────────────────────────────
export async function ollamaRunning() {
  try{ const r=await fetch('http://localhost:11434/api/tags'); return r.ok }catch{ return false }
}

export async function ollamaModels() {
  try{ const r=await fetch('http://localhost:11434/api/tags'); const d=await r.json(); return(d.models||[]).map(m=>m.name) }
  catch{ return [] }
}

export async function pullModel(name, onProgress) {
  const r=await fetch('http://localhost:11434/api/pull',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,stream:true})})
  const reader=r.body.getReader(),dec=new TextDecoder()
  while(true){const{done,value}=await reader.read();if(done)break;for(const l of dec.decode(value).split('\n').filter(Boolean)){try{onProgress(JSON.parse(l))}catch{}}}
}

export async function deleteModel(name) {
  await fetch('http://localhost:11434/api/delete',{method:'DELETE',headers:{'Content-Type':'application/json'},body:JSON.stringify({name})})
}

export const OLLAMA_MODELS = [
  {id:'llama3.2:1b',   name:'Llama 3.2 1B',   size:'0.8 GB',ram:'4 GB+', tag:'Fastest',    color:'#5a8a5a'},
  {id:'llama3.2:3b',   name:'Llama 3.2 3B',   size:'2 GB',  ram:'6 GB+', tag:'Recommended',color:'#c4902a'},
  {id:'llama3.1:8b',   name:'Llama 3.1 8B',   size:'4.7 GB',ram:'10 GB+',tag:'Smart',       color:'#5a7aaa'},
  {id:'mistral:7b',    name:'Mistral 7B',     size:'4.1 GB',ram:'8 GB+', tag:'Sharp',       color:'#8a5aaa'},
  {id:'phi3:mini',     name:'Phi-3 Mini',     size:'2.2 GB',ram:'6 GB+', tag:'Efficient',   color:'#5a9aaa'},
  {id:'gemma2:2b',     name:'Gemma 2 2B',     size:'1.6 GB',ram:'4 GB+', tag:'Compact',     color:'#aa6a5a'},
  {id:'deepseek-r1:7b',name:'DeepSeek R1 7B', size:'4.7 GB',ram:'10 GB+',tag:'Reasoning',   color:'#aa8a40'},
  {id:'qwen2.5:7b',    name:'Qwen 2.5 7B',    size:'4.4 GB',ram:'8 GB+', tag:'Multilingual',color:'#5aaa7a'},
]

export const CLOUD_MODELS = {
  openai:    [{id:'gpt-4o',name:'GPT-4o'},{id:'gpt-4o-mini',name:'GPT-4o Mini'},{id:'gpt-4-turbo',name:'GPT-4 Turbo'}],
  anthropic: [{id:'claude-opus-4-5',name:'Claude Opus'},{id:'claude-sonnet-4-5',name:'Claude Sonnet'},{id:'claude-haiku-4-5-20251001',name:'Claude Haiku'}],
}
