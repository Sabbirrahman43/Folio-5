import * as pdfjs from 'pdfjs-dist'
import workerUrl from 'pdfjs-dist/build/pdf.worker.min.js?url'
pdfjs.GlobalWorkerOptions.workerSrc = workerUrl

// Module-level PDF document cache for comic page rendering
let _pdf = null

export async function extractBook(base64) {
  const bytes = Uint8Array.from(atob(base64), c => c.charCodeAt(0))
  _pdf = await pdfjs.getDocument({ data: bytes }).promise

  const pages = []
  let imagePageCount = 0

  for (let i = 1; i <= _pdf.numPages; i++) {
    const page = await _pdf.getPage(i)
    const content = await page.getTextContent()

    let text = '', lastY = null, lastX = null
    for (const item of content.items) {
      if (!item.str) continue
      const y = Math.round(item.transform[5])
      const x = Math.round(item.transform[4])
      if (lastY !== null) {
        const dy = Math.abs(lastY - y)
        if (dy > 14) text += '\n\n'
        else if (dy > 4) text += '\n'
        else if (lastX !== null && x - lastX > 20) text += ' '
      }
      text += item.str; lastY = y; lastX = x + (item.width || 0)
    }

    const trimmed = text.trim()
    // Page is image-based if it has almost no extractable text
    const isImagePage = trimmed.length < 40
    if (isImagePage) imagePageCount++
    pages.push({ num: i, text: trimmed, isImagePage })
  }

  // Comic/manga mode: majority of pages are image-based
  const isComic = _pdf.numPages > 0 && (imagePageCount / _pdf.numPages) > 0.6

  return { pages, totalPages: _pdf.numPages, isComic }
}

// Render a single PDF page to a data URL (used by comic reader)
// Uses the cached _pdf document from the last extractBook call
export async function renderPage(pageNum, scale = 1.8) {
  if (!_pdf) throw new Error('No PDF loaded')
  const page = await _pdf.getPage(pageNum)
  const viewport = page.getViewport({ scale })
  const canvas = document.createElement('canvas')
  canvas.width = viewport.width
  canvas.height = viewport.height
  const ctx = canvas.getContext('2d')
  await page.render({ canvasContext: ctx, viewport }).promise
  return canvas.toDataURL('image/jpeg', 0.92)
}

export function textToBlocks(raw) {
  if (!raw) return []
  const blocks = []
  for (const section of raw.split(/\n\n+/)) {
    const t = section.trim(); if (!t) continue
    const lines = t.split('\n').filter(l => l.trim())
    const first = lines[0]?.trim() || ''
    const isHeading = first.length < 70 && !first.endsWith('.') && (
      /^(chapter|part|section|prologue|epilogue|introduction|preface|appendix|act\s)/i.test(first) ||
      (first === first.toUpperCase() && first.replace(/\s/g, '').length > 2) ||
      /^\d+[\.]\s+[A-Z]/.test(first)
    )
    if (isHeading) {
      blocks.push({ type: 'heading', text: first })
      const rest = lines.slice(1).join(' ').trim()
      if (rest) blocks.push({ type: 'paragraph', text: rest })
    } else {
      const full = lines.join(' ').replace(/\s+/g, ' ').trim()
      if (full) blocks.push({ type: 'paragraph', text: full })
    }
  }
  return blocks
}
